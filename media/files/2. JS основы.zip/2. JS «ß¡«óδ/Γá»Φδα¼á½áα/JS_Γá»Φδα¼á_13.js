
// === Задача 1 === //
// Фамилияны кыскартып беруучу функция
function shortFio(fio) {
    let splitted = fio.split(' ')
    if(splitted.length === 2) {
        console.log(`${splitted[0][0]}.${splitted[1][0]}`)
    } else if(splitted.length === 3) {
        console.log(`${splitted[0][0]}.${splitted[1][0]}.${splitted[2][0]}`)
    }
}

shortFio('Садыр Жапаров') // С. Ж.
shortFio('Асылбек уулу Санжар') // А.у.С.
shortFio('Абжапар кызы Кызжибек') // А.у.С.


// === Задача 2 === //
// Берилген фио дон атын кыскартып беруучу функция туз
function shortLongFio(fio) {
    let splt = fio.split(' ')
    if(splt.length === 2) {
        console.log(`${splt[0]} ${splt[1][0]}.`)
    } else if(splt.length === 3) {
        console.log(`${splt[0]} ${splt[1]} ${splt[2][0]}.`)
    }
}
shortLongFio('Асилов Залкарбек') // Асилов З.
shortLongFio('Асылбек уулу Сыймык') // Асылбек уулу С.
shortLongFio('Мунарбек уулу Нурислам') // Мунарбек уулу Н.


// === Задача 3 === //
function kvartal(month) {
    let m = month.toUpperCase()
    let kravtal_1 = ['ЯНВАРЬ', 'ФЕВРАЛЬ', 'МАРТ']
    let kravtal_2 = ['АПРЕЛЬ', 'МАЙ', 'ИЮНЬ']
    let kravtal_3 = ['ИЮЛЬ', 'АВГУСТ', 'СЕНТЯБРЬ']
    let kravtal_4 = ['ОКТЯБРЬ', 'НОЯБРЬ', 'ДЕКАБРЬ']
    if(kravtal_1.includes(m)) {
        console.log('1 кварталга кирет')
    } else if(kravtal_2.includes(m)) {
        console.log('2 кварталга кирет')
    }else if(kravtal_3.includes(m)) {
        console.log('3 кварталга кирет')
    }else if(kravtal_4.includes(m)) {
        console.log('4 кварталга кирет')
    }
}

kvartal('Февраль') // 1 кварталга кирет
kvartal('Август') // 3 кварталга кирет
kvartal('Ноябрь') // 4 кварталга кирет


// === Задача 4 === //
function aimanZhuc(a1, a2) {

}

aimanZhuc('Кагаз', 'Кайчы') // 2 адам женди
aimanZhuc('Таш', 'Кагаз') // 2 адам женди
aimanZhuc('Таш', 'Кайчы') // 1 адам женди
aimanZhuc('Таш', 'Таш') // Ничья


// === Задача 5 === //
// тетири массив тузот
function reversedArray(n) {

}
reversedArray(5) // [5,4,3,2,1]
reversedArray(3) // [3,2,1]
reversedArray(-7) // [-1,-2,-3,-4,-5,-6,-7]

// === Задача 6 === //
// Берилген текст санбы же сан эмесби аныктап бер
function isSan(san) {

}

isSan('123') // true
isSan('-уasb123') // true
isSan('a123b') // false
isSan('b2022') // true
isSan('text2022') // true
isSan('-2022-') // false
isSan('2022_00') // true
isSan('-2022_00#') // false
isSan('true') // false