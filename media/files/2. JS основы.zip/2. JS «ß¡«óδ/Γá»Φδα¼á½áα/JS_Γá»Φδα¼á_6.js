
let notebook = 'Asus Strix 2021'
let notebook_price = 69000
let skidka_1 = 0.20

let notebook_2 = 'Acer Predator'
let notebook_price_2 = 79000
let skidka_2 = 0.17

let notebook_3 = 'MacBook Pro 2020'
let notebook_price_3 = 99000
let skidka_3 = 0.30

let my_money = prompt('Сколько у тебя денег ?')

/*
    Спросите у пользователя какой ноутбук он хочет купить
    Зависимости от выбранного ноутбука продадите ему выбранный ноутбук c учетом скидки
*/