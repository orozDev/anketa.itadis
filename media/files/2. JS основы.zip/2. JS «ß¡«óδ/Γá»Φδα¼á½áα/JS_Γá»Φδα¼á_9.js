
// === Задача 1 ===
// function dup(san, op) {
//     let text = ''
//     let sum = 0
//     if(op === '+') {
//         for(let i = 1; i <= san; i++) {
//             if(i === 1) {
//                 text = `${i}`
//             } else {
//                 text = `${text}+${i}`
//             }
//             sum = sum + i
//         }
//         text = `${text} = ${sum}`
//         console.log(text)
//     } else if(op === '*') {
//         sum = 1
//         for(let i = 1; i <= san; i++) {
//             if(i === 1) {
//                 text = `${i}`
//             } else {
//                 text = `${text}*${i}`
//             }
//             sum = sum * i
//         }
//         text = `${text} = ${sum}`
//         console.log(text)
//     }
// }

// dup(10_000, '+') // 1+2+3+4...10 = ?
// dup(500, '*')  // 1*2*3*4*5 = ?
// dup(5, '-')  // 1-2-3-4-5 = ?


// === Задача 2 ===
function table(num, rate) {

}

// /*
//     Задача функции вывести на экран таблицу умножения
//     tabler(5, 10)
//     5 x 1 = 5
//     5 x 2 = 10
//     5 x 3 = 15
//     .........
//     5 x 100 = 500
// */
table(5, 100)

// /*
//     tabler(7, 10)
//     7 x 1 = 5
//     7 x 2 = 10
//     7 x 3 = 15
//     .........
//     7 x 100 = 700
// */
table(7, 100)


// === Задача 3 ===
function to_hello(lang) {

}

to_hello('kg') // Салам кандайсын, иштерин кандай ?
to_hello('ru') // Привет друг как дела ?
to_hello('en') // Hi friend how are you ?
to_hello('fr') // на французком ?
to_hello('kz') // Калайсын ?