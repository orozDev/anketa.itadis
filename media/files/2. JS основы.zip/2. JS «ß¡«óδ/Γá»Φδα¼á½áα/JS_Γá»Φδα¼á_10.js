// уйдон окуйбуз
// https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Global_Objects/String

// search
// replace
// repeat
// split - керектуу метод
// concat


// 2 Массивдин жардамчы методдору
// https://learn.javascript.ru/array
// https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Global_Objects/Array