
// === Задача 1 ===
// prompt жана цикл колдонуу менен 5 тамактын обьектисин кошкула
let tamaktar = []

for(let i = 0; i < 5; i++) {
    let tamak = {}
    tamak.name = prompt('Тамактын аты')
    tamak.price = +prompt('Ошол эле тамактын ценасы')
    tamaktar.push(tamak)
}
console.log(tamaktar)

// === Задача 2 ===
// колдонуучудан сураныз
// prompt аркылуу чонтогунуздо канча акча бар деп сура ?
/*
    Эгерде клиенттин акчасы tamaktar массивиде жайгашкан кайсы бир тамактын акчасына жетсе ошол тамакты алып жей аласыз деп чыгарып бер
*/
let acha = +prompt('Чонтогунуздо канча акча бар ?')
for(let i = 0; i < 5; i++) {
   if(tamaktar[i].price <= acha) {
       console.log('Сиз', tamaktar[i].name, 'жей аласыз')
   }
}


// === Задача 3 ===
// Озунордун ноутбугунардын характеристикасын обьект кылып жазып келгиле


// === Задача 4 ===
// let students = [
//     {
//         name: 'Alex',
//         age: 17,
//         univer: 'ОшМу'
//     },
//     {
//         name: 'John',
//         age: 16,
//         univer: 'Manas'
//     },
//     {
//         name: 'Tom',
//         age: 21,
//         univer: 'OshTu'
//     },
//     {
//         name: 'Kuk',
//         age: 19,
//         univer: 'OshTu'
//     },
//     {
//         name: 'Bill',
//         age: 18,
//         univer: 'OshTu'
//     },
//     {
//         name: 'Rock',
//         age: 24,
//         univer: 'OshTu'
//     },
//     {
//         name: 'Elaman',
//         age: 21,
//         univer: 'OshTu'
//     },
// ]
// окуучулардын жашына карап кайсыл окуганын аныктап беруучу программа туз
// Мисалы Асан 18 жашта мектепте 11 класста окуйт


// Кошумча уйдон окуйбуз
// https://learn.javascript.ru/object
// https://learn.javascript.ru/array-methods