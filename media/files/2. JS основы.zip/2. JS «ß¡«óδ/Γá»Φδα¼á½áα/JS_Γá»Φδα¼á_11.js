// === Задача 1 ===
// HTML и CSS кайталайбыз
// Javascript обьекты ушул ссылкадан окуйбуз
// https://learn.javascript.ru/object