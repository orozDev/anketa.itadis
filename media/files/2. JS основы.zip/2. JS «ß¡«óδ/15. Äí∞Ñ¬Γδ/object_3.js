
let friends = [
    {
        name: 'Калыс',
        address: 'Западный',
        study: 'Манас мектеби'
    },
    { 
        name:`Бек`, 
        address:`Ак-Тилек`, 
        study:`52-Мектеп` 
    }, 
    { 
        name:`Залкар`, 
        address:`Ноокат`, 
        study:`Кашкалдак мектеби` 
    } 
]

let index = 0
while(index < friends.length) {
    console.log(index + 1, friends[index].name)
    index++
}



