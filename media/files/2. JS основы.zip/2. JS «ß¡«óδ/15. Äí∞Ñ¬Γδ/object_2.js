
let kyrgyzstan = {
    place: 'Цетральная Азия',
    borbor: 'Бишкек',
    GPS: {
        dolgota: '47.6586989',
        shirina: '46.4975413',
        duration: {
            speed: 123,
            pogoda: 'Солнечный'
        }
    },
    population: 6_500_000,
    langs: ['Кыргызский', 'Русский']
}
console.log(kyrgyzstan.GPS.duration.pogoda)
console.log(kyrgyzstan.langs[1])