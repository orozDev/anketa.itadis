// let name = 'Чынгыз'
// let age = 14
// let height = '1.75м'
// let kg = '58кг'
// let color = 'white'
// let type = 'human красавчик'
// let iq = '165 акылдуу'

// Обьект Object
// let human = {
//     name: 'Чынгыз',
//     age: 14,
//     height: '1.75м',
//     kg: '58кг',
//     color: 'white',
//     type: 'human красавчик',
//     iq: '165 акылдуу'
// }

// console.log(human.name)
// console.log(human.age)
// console.log(human.height)

// let car = {
//     model: 'Toyota Camry',
//     type: '70 кузов',
//     year: '2020',
//     vol: 2.4,
//     color: 'Серебристый',
//     rule: 'Левый',
//     korobka: 'Автомат'
// }

// console.log('Модель машины ', car.model)
// console.log('Обьем двигателя', car.vol)
// console.log('Цвет машины', car.color)
// console.log('Руль машины', car.rule)
// console.log('КПП', car.korobka)


// let animal = {
//     name: 'Панда🐼',
//     type: 'Палпыс',
//     eat: 'Бам-бук',
//     live: 'Кытай',
// }
//  console.log("Аты:",animal.name)
//  console.log("Тип:",animal.type)
//  console.log("Жейт:",animal.eat)
//  console.log("Жашайт:",animal.live)


// Обьект игрового персонажа
// let kamil = {
//     xp: 200,
//     mp_speed: 5,
//     mp_text: '5xp в секунду',
//     attack : 45,
//     speed: 20,
//     tip: 'Камил'
// }

// // уменьшаем жизнь камиля
// kamil.xp = kamil.xp - kamil.attack // xp 170
// kamil.xp = kamil.xp + kamil.mp_speed
// kamil.speed = 65
// kamil.energy = 100
// console.log(kamil)

let TankBattleMaster = {
    name: 'Танка Король Боя',
    country: 'Китай',
    xp: 1000,
    attack: 120,
    speed: 30, // 30km в час
    visible: 500,
    attack_distance: 250
}

let TankMamont = {
    name: 'Танка Мамонт',
    country: 'ГЛА',
    xp: 5000,
    attack: 180,
    speed: 70, // 30km в час
    visible: 500,
    attack_distance: 300
}

let TankComander = {
    name: 'Танка Командир', 
    country: 'США', 
    xp: 6000, 
    attack: 350, 
    speed: 60, // 30km в час 
    visible: 500, 
    attack_distance: 450 
}

while(TankComander.xp > 0 || TankMamont.xp > 0) {
    if(TankComander.attack_distance > TankMamont.attack_distance) {
        TankMamont.xp = TankMamont.xp - TankComander.attack
        TankComander.xp = TankComander.xp - TankMamont.attack*2
    } else {
        TankComander.xp = TankComander.xp - TankMamont.attack*2
        TankMamont.xp = TankMamont.xp - TankComander.attack
    }
    if(TankComander.xp < 0) {
        console.log('TankMamont выйграл')
        break
    }
    if(TankMamont.xp < 0) {
        console.log('TankComander выйграл')
        break
    }
    console.log(`XP TankCommander = ${TankComander.xp}`)
    console.log(`XP TankMamont = ${TankMamont.xp}`)
}
console.log(`XP TankCommander = ${TankComander.xp}`)
console.log(`XP TankMamont = ${TankMamont.xp}`)
