// .length  длина строки
// .replace(Старая строка, Новая строка) Заменяет старую строку на новую строку
// .repeat(n) повторить текст n ное раз

// let stroka = 'пароль  '
// console.log(stroka.length)

// let pc = "1336"
// console.log(pc.length)

// let news = 'Садыр Жапаров бугун Стив Джобс менен жолукту.'

// news = news.replace('Стив Джобс', 'Билл Гейтс')
// console.log(news)

// let superHero = 'Человек-Паук '
// console.log(superHero.repeat(10))

// ======== Задача 1 =========
// fraza озгормонун ичиндеги ичиндеги туура эмес создорду алмаштыр
// let fraza = 'Я родился и вырос в Москве'


// ======== Задача 2 =========
// экранга алмадан 5шт чыгар
// экранга lemon 3шт чыгар
// экранга watermelon 4шт чыгар
// экранга banana 10шт чыгар
// let apple = '🍎'
// let lemon = '🍋'
// let watermelon = '🍉'
// let banana = '🍌'

// console.log(apple.repeat(5))

