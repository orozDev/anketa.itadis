

// let x = 8
// console.log(x ** 2)
// console.log(x ** 3)
// console.log(x ** 4)
// console.log(x ** 5)
// console.log(x ** 6)

let x = 10
let y = 5
console.log(x * 100 / 2 - 200 + y + x**2 * 3.5)