
// KG -> озгормо  RU -> переменные

// KG озгормо тузуунун эрежеси
// RU правила создания переменного
// let <имя переменного> = какое то значение

let names = 'Steve Jobs'
let youtube = 'https://youtube.com'
let chyngyz_telegram = 'https://web.telegram.org/chyngyz'
let age = 18

