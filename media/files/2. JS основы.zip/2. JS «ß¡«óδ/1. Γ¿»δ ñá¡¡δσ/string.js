
'hello' // текст
'500' // текст
"Hello Alex" // текст
`Hello Chyngyz` // текст