
let san = 100 // сандык типтеги озгормо
let text = 'hello world' // текстик типтеги озгормо
let bool = true // шарттык типтеги озгормо