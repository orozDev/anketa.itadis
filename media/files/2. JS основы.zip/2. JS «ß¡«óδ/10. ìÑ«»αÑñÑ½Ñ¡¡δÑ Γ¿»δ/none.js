
// === Не определенные типы === //
// undefined - не определенный тип false
// null - ничего, пустой тип false
// NaN - Not a Number - не число true

// let number // по умолчанию значение undefined
// let name = null // пустое значение
// let num1 = parseInt('text') // NaN


// === ПРОВЕРКА НА НЕ ОПРЕДЕЛЕННЫЕ ЗНАЧЕНИЕ ===
let num1 = undefined
let num2 = null
let num3 = NaN


// проверка на не определенность
if(typeof num1 === 'undefined') {
    console.log('num1 озгормонун тиби undefined')
}

// console.log(typeof num1)
// console.log(typeof num2)
// console.log(typeof num3)

// проверка на null
// пустая ли переменная num2 
if(num2 === null) {
    console.log('num2 пустая переменная')
} else {
    console.log('num2 не пустая переменная')
}

// Проверка на не число
if(isNaN(num3)) {
    console.log('num3 не число')
}