
// let numbers = [18, 16, 15, 24, 35, 17, 18, 3, 2, 6, 14, 99, -9]

// // сортировка массива
// console.log(numbers)
// numbers.sort(function(a, b) {
//     return a - b
// })
// console.log(numbers)

// удалить из массива -900 и 0
// let numbers = [5000, 9000, 6000, -900, 2022, 0]
// numbers.splice(3, 1)
// numbers.pop()
// console.log(numbers)


// Обьединить массив в один текст
// let years = [2000,2002,2003,2004,2005,2006,2007,2008,2009,2010]

// let year_text = years.join('-')
// console.log(year_text)

