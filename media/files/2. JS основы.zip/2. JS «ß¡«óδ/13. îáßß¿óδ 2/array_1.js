// redmi-devops - 0770145141


let friends = [
    'Axe',
    'Bill',
    'Tom'
]

// Добавление новых элементов в конец массив
friends.push('Rok', 'Kek')
console.log(friends)

// Добавление новых элементов в начало массива
friends.unshift('Wik', 'Dek')
console.log(friends)

// Обьеденить два массива в один массив
let friends_old = ['Tuk', 'Tik', 'Tok']
let friend_new = friends.concat(friends_old, ['Yoj', 'Mob'])

console.log(friend_new)


// удаление последнего элемента из массива
friend_new.pop()
console.log(friend_new)


// удаление первого элемента из массива
friend_new.shift()
console.log(friend_new)


// Удаление элемента начиная с индекса и кол-во удаляемых элементов
friend_new.splice(4, 1)
console.log(friend_new)