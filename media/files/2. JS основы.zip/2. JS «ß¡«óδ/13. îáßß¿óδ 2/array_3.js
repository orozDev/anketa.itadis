let guests = [
    'Санжар',
    'Сыймык',
    'Чынгыз'
]

// поиск элемента из массива, если есть то дает мне  его индекс, если не нашел то дает -1
// guests.indexOf('Чынгыз') // 2
// guests.indexOf('Alex') // -1

let index = guests.indexOf('Чынгыз')
console.log(guests[index], 'я нашел тебя из массива')


// поиск элемента из массива, если есть то true иначе false
guests.includes('Санжар') // true - есть, false - жок