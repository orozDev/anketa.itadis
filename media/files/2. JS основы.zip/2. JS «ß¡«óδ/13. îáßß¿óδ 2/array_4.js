let presidents = [
    'Аскар Акаев',
    'Курманбек Бакиев',
    'Роза Отумбаева',
    'Алмазбек Атамбаев',
    'Сооронбай Жээнбеков',
    'Садыр Жапаров'
]

// for(let i = 0; i < presidents.length; i++) {
//     console.log(presidents[i], '1991-2006')
// }

// Перебор массива
// Перебирает каждый массив и выполняет функцию для каждого элемента массива
presidents.forEach(function(president) {
    if(president === 'Роза Отумбаева') {
        console.log(president, '2010-2011')
    } else {
        console.log(president)
    }
})
