
// let numbers = [34, 90, 78, 56, 43, 21, 99, 56, 234, 346, 467, 234, 875, 234]

// let sum = 0

// for(let i = 0; i < numbers.length; i++) {
//     console.log(numbers[i])
//     sum = sum + numbers[i]
// }

// console.log('Сумма всех чисел массива равна', sum)


let numbers = [34, 90, 78, 56, 43, 21, 99, 56, 23, 34, 46, 23, 8, 2];

// выведите только те числа которые больше 50
for(let i = 0; i < numbers.length; i++) {
    if(numbers[i] > 50) {
        console.log(numbers[i])
    }
}