// let puples = `
//     Санжар 
//     Чынгыз 
//     Нурислам
//     Бек
//     Сыймык
//     Данияр
//     Залкар
// `

// Массив(Список) - Array - Тизме
// let students = [
//     'Санжар', 
//     'Чынгыз', 
//     'Нурислам', 
//     'Бек', 
//     'Сыймык', 
//     'Данияр', 
//     'Залкар'
// ]

// console.log(students[3] + students[5])


// let languages = [
//     'Кыргызский', 
//     'Русский', 
//     'English'
// ]

// languages[2] = 'Английский'
// languages[4] = 'Турецкий'
// languages[99] = 'Испанский'

// console.log(languages.length)


// ===== Задание 1 =====

// Предметтердин тизмесин туз
// let predmets = ['']


// // ===== Задание 2 =====
// // поменяйте местами 0 элемента и 2 элемента
// let phones = [
//     'iPhone 13 Pro Max', 
//     'Samsung Galaxy 22 Ultra', 
//     'Poco X NFS'
// ]

// let a1 = phones[0]
// phones[0] = phones[2]
// phones[2] = a1

// console.log(phones)


