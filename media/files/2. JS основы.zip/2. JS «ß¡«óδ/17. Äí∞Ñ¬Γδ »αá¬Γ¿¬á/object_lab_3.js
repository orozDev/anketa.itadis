// === Задача 3 ===
// 1 Найти друзей которые заходят в Тикток
// 2 Найти друзей которые заходят в Facebook и Telegram
// 3 Найти друзей которые заходят в Инстаграм но не заходят в Телегу
let friends = [
    {
        name: 'Mike',
        address: 'г.Ош Араванский',
        social: ['Tiktok', 'Instagram', 'Facebook', 'Viber', 'Telegram']
    },
    {
        name: 'Tim',
        address: 'г.Ош Западный',
        social: ['Tiktok', 'Instagram']
    },
    {
        name: 'Kuk',
        address: 'г.Джалал-Абад Акт-тилек',
        social: ['Facebook', 'Viber', 'Instagram']
    },
    {
        name: 'Rudi',
        address: 'г.Ош Зайнап',
        social: ['Viber', 'Telegram', 'Tiktok']
    },

    {
        name: 'Alon',
        address: 'г.Ош Запад',
        social: ['Viber', 'Telegram', 'Instagram']
    }
]

for (let i = 0; i < friends.length; i++) { 
    if (
        friends[i].social.includes('Instagram') 
        &&
        !friends[i].social.includes('Telegram')
    ) {
        console.log(friends[i].name); 
    } 
}
