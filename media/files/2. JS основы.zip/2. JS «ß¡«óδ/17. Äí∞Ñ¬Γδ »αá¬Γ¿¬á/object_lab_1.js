
// #1 выведи на экран всех людей
// #2 выведи на экран только Программистов
// #3 выведи на экран только Юристов
// #4 выведи на экран всех кроме Программистов

let persons = [
    {"name": "Эрлан",'post': 'Адвокат'},
    {"name": "Адахан",'post': 'Юрист'},
    {"name": "Бекжан",'post': 'Программист'},
    {"name": "Даниэл",'post': 'Программист'},
    {"name": "Алтынай",'post': 'Парикмахер'},
    {"name": "Жибек",'post': 'Повар'},
    {"name": "Элижан",'post': 'Юрист'}
]
console.log('==== ВСЕ ====')
for(let i = 0; i < persons.length; i++) {
    console.log(persons[i].name, persons[i].post)
}

console.log('==== ПРОГРАММИСТЫ ====')
for(let i = 0; i < persons.length; i++) {
    if(persons[i].post === 'Программист') {
        console.log(persons[i].name, persons[i].post)
    }
}

console.log('==== ЮРИСТЫ ====')
for(let i = 0; i < persons.length; i++) {
    if(persons[i].post === 'Юрист') {
        console.log(persons[i].name, persons[i].post)
    }
}

console.log('==== НЕ ПРОГРАММИСТЫ ====')
for(let i = 0; i < persons.length; i++) {
    if(persons[i].post !== 'Программист') {
        console.log(persons[i].name, persons[i].post)
    }
}