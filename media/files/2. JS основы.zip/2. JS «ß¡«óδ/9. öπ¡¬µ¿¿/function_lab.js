// функция вычисляет сколь километров в n сантиметре
function sm_to_km(sm) {
    return (sm / 100) / 1000
}
// функция вычисляет сколь сантиметров в n километре
function km_to_sm(km) {
    
}
// функция вычисляет сколь километров в n милиметре
function ml_to_km(ml) {

}

let total_km = sm_to_km(150_000) // см -> км
let total_sm = km_to_sm(10_000) // км -> см
let total_km2 = ml_to_km(100_000) // мл -> км
console.log(150_000, 'см де', total_km, 'км бар')
console.log(10_000, 'км де', total_sm, 'см бар')
console.log(100_000, 'мл де', total_km2, 'км бар')
