
// Возвравщение результата функции после вызова
function sum(a, b) {
    return a + b
}

let result = sum(11, 90)

console.log(result)