
function max(a, b) {
    if(a > b) {
        console.log(`${a} чон ${b} д-н`)
    } else if(a === b) {
        console.log(`${a} барабар ${b} га`)
    } else {
        console.log(`${b} чон ${a} д-н`)
    }
}

max(56, 98)
max(0.002, 0.02)

max(10, 10)
