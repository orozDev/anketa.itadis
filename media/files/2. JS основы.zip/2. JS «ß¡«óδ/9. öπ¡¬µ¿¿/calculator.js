
function calc(san1, san2, op) {
    // op === + - / *
    if(op === '+') {
        console.log('')
    }
}

calc(100, 200, '+')
calc(58, 96, '-')
calc(12, 24, '/')
calc(63, -35, '*')