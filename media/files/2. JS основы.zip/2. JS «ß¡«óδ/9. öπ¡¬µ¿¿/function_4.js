
function sum(san1, san2) {
    let sum = san1 + san2
    console.log(`${san1} + ${san2} = ${sum}`)
}

function minus(san1 , san2) {

}

function boluu(san1 , san2) {

}

function koboytuu(san1 , san2) {

}

sum(900, 899) //
sum(900, 450) //