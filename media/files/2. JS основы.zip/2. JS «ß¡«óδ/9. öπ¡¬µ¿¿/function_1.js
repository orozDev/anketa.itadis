
// Создание функции
function sayHello() {
    let i = 0
    console.log('=== Функция вызывается ===')
    while( i <= 3) {
        console.log('Hello', i)
        i++
    } 
}

// Запуск функции
sayHello()
// // Запуск функции 2 раз
sayHello()
sayHello()