let friends = ['Alex', 'John', 'Tom']


function helloFriend() {
    console.log('Салам', friends[0])
    console.log('Bonju', friends[1])
    console.log('Guden tak', friends[2])
}

helloFriend()
