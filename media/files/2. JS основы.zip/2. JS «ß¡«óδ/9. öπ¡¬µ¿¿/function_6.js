function percent(number, per) {

}


percent(1000, 500) //  50%
percent(100, 30) //  30%
percent(9863, 789) // ?
percent(6_000_000, 1_450_330) // 