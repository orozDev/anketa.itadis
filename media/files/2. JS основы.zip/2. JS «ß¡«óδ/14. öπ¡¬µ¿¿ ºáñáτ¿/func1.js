
function speedTime(speed, km) {
    return km / speed
}

let speed = 600
let km = 450
let transport = 'Самалет'

let carTime = speedTime(speed, km) 
console.log(`
    ${transport} ${km} км аралыкты ${carTime} саатта басып отот.
`)
