
// // узнать длину текста length
// let text1 = 'Привет меня зовут текст'
// console.log(text1.length)

// // Менять регистр символов на большие символы
// let text2 = 'Что за текст почему он текст ?'
// console.log(text2.toUpperCase())

// // Все маленькими буквами
// let text3 = 'Почему Ты стАл малЕньКиМ ЧЕЛОВЕЧКОМ ?'
// console.log(text3.toLowerCase())

// // Поиск слов из текста, Если есть возвращает позицию текста
// let text4 = `Кыргызстандын залкар уулу, дүйнөгө аты таанымал белгилүү жазуучу, коомдук жана мамлекеттик ишмер Чыңгыз Айтматов Талас облусуна караштуу Кара-Буура районундагы Шекер айылында 1928-жылы 12-декабрда туулган.
// `
// console.log(text4.indexOf('уулу')) // 21
// console.log(text4.indexOf('1928')) // 175

// Есть ли текст в тексте
let text5 = 'Good morning 🦁 and 🐶'
console.log(text5.includes('🦁')) // true
console.log(text5.includes('good')) // false
console.log(text5.includes('🙊')) // false


let text6 = `Этот метод был добавлен в спецификации ECMAScript 2015 и может быть недоступен в некоторых реализациях JavaScript. Однако, можно легко эмулировать этот метод
`

console.log(text6.includes('  можно легко эмулировать')) // false

// убрать лишние пробелы с начала и с конца строки
let searchtext = '       можно   легко '
console.log(searchtext.trim()) // 'можно   легко'