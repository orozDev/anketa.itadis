let number = 100
let number2 = 'fake'

try {
    console.log(number)
    console.log(number)
    console.log(number)
    console.log(number)
    console.log(number)
    console.log(number[0].name)
    console.log(number2)
} catch(e) {
    console.log('Что то пошло не так программа не работает')
}
