
let n = +prompt('Введите число')

try {
    alert(`Квадрат числа ${n*n[0].name}`)
} catch(error) {
    alert('Ошибка, обратитесь системному Администратору')
    console.log(error.name)
    console.log(error.message)
}

