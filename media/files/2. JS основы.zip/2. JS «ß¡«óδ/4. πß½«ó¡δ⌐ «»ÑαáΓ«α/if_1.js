
let samsung21 = 36000
let me_money = 38000

if(me_money >= samsung21) {
    console.log('Ты можешь купить Samsung S20 телефон')
} else {
    console.log('Брат ты лучше купи Redmi Note 12')
}