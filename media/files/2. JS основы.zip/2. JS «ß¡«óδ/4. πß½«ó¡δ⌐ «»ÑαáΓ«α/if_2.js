
let age = 15

if(age >= 18) {
    console.log('Биздин кафеге кош келиниз')
} else {
    console.log('Кечиресин укам сенин жашын жете элек')
}

