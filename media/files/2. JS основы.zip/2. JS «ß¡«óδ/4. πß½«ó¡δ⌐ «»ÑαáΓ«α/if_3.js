
// let som = 310 // Биздин чонтоктогу акчабыз

// let lagman = 170 // Лагмандын ценасы
// let sup = 145 // шорпо
// let fish = 235 // балык
// let meat = 220 // казакский
// let kuurdak = 350 // куурдак

// if(som >= lagman) {
//     console.log('Лагман жей аласын')
// }

// if(som >= sup) {
//     console.log('Шорпо иче аласын')
// }

// if(som >= fish) {
//     console.log('Балык жей аласын')
// }

// if(som >= meat) {
//     console.log('Казакский жей аласын')
// }

// if(som >= kuurdak) {
//     console.log('Куурдак жей аласын')
// }


let deposit = 300_000
let toyota_camry_2021 = 900_000
// Кыргызстан банктан жылына 40% ставка менен депозитке 7 жылга койсок болот.
// Оптима банктан жылына 38% ставка менен депозитке 9 жылга койсок болот.
// Демир банктан жылына 39% ставка менен депозитке 7 жылга койсок болот.

let cbc_money = deposit * 0.40 * 7
let optima_money = deposit * 0.38 * 9
let demir_money = deposit * 0.39 * 7

if(cbc_money >= toyota_camry_2021) {
    console.log('Ваши деньги в Кыргызстан банке', cbc_money)
    console.log('Вы можете купить тойота камри')
}

if(optima_money >= toyota_camry_2021) {
    console.log('Ваши деньги в Оптима банке', optima_money)
    console.log('Вы можете купить тойота камри')
}

if(demir_money >= toyota_camry_2021) {
    console.log('Ваши деньги в Демир Банке', demir_money)
    console.log('Вы можете купить тойота камри')
}


