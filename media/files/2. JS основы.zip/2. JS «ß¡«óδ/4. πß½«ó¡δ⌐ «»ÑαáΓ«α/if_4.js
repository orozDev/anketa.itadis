let san = 500 * 300 / 300.5

let n = 500
if(san > n) {
    console.log(san, '100 чон')
} else {
    console.log(san, '100 дон кичине')
}