
// let president = 'Садыр Жапаров'

// console.log(president)

// console.log(300 + (-600))


// let text1 = 'Садыр Жапаров'
// let text2 = "Садыр Жапаров"
// let text3 = `Садыр Жапаров`

// console.log(text1 === text3)

// let year = 2020
// let year2 = '2020'

// console.log(year === year2)


// let first = 'Алмазбек'
// let last = 'Атамбаев'

// first = last
// last = 'Сооронбай'
// first = 'Жээенбеков '

// console.log(first + last)

/*
    Блочный комментарий
*/

// let money = '27 000 000 $'
// money = '1000 $'

// console.log(money)


// let elcard = -1

// elcard = 500 + elcard
// elcard = elcard * 10

// elcard = elcard + 5000

// console.log(elcard)

// Банктагы сотрудниктин айлыгы
let zarplata = 29000
// 1 айлык айлыгынан задержка пайыз
let credit_stavka = 10
// зарплатанын 10% 
credit_stavka = zarplata * (credit_stavka / 100)

// 1 айлык расход
let bir_ai_rashod = 13500

// 1айда алган акчасы
let dohod = zarplata - bir_ai_rashod - credit_stavka
console.log('Бир айда доход табат =', dohod)

// 1 жылда топтогон акчасы
let dohod365 = dohod * 12
console.log('Бир жылда доход табат =', dohod365)