let country = 'Кыргызстан'

console.log(country * 10)